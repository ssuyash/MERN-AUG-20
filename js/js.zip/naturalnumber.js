
//for first n number

// for(var i=1; i<=10; i++){
//     console.log(i)
// }










//////////////////////////////////////////////////////////////////////
// AP >> 
//     a first term
//     d difference


//     nth => 

//     sum (a+(n-1)*d)

// AM 

// var n = 10
// var sum = (n*(n+1))/2
// console.log(sum)


// var sum = 0;
// for(var i=1; i<=n; i++){
//     sum += i
// }
// console.log(sum)



var n = 19

for (var num = 1; num<=n; num++){
    var tabStr = ""
    for(var i = 1; i<=10; i++){
        tabStr += num+" x " + i + " = " + num*i+" "
    }    
    console.log(tabStr)
}


