var a = 5
var b = 100


a = a+b
b = a-b



console.log("After Swapping ", a, b)

