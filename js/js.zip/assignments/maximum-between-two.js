var a = 100
var b = 200


if(a > b){
    if(a > c){
        
    }else{
        c
    }
    console.log(a, " is Greater than ", b)
}else{
    console.log(b, " is Greater then ", a)
}



if(num > 0){
    pos
}else if num( num < 0){
    neg
}else{
    zero

}

num%5 == 0 && num%11 ==0




a
b
c

x+y+z = 180
a+b >c
a+c > b
b+c > a


ax2 + bx + c = 0

d = b2 - 4ac

alpha = -b - root(D)  /  2a


cost price
selling price

selling - cost

+ve > profit
-ve > loss
0   > cost to cost



per =   (m+c+b+ph+com)/5 


basic = 8000
gross = 8000 + 8000*.2  + 8000*.0



360

50 * *0.50   > 310

100 *0.75   > 210

100 * 1.20 > 110

110 * 1.50 




total = 1520 + 1520*.15