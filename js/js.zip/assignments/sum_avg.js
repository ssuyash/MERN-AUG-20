// var sum = 0

// for(var i=1; i<=10; i++){
//     sum += parseInt(prompt("Enter number"))
// }

// var avg = sum/10

// console.log("sum ", sum, " Avg. ", avg)


// var input = parseInt(prompt("Enter number"))
// console.log(input)