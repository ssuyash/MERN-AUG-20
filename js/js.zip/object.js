var person = {
    name:'Suyash', 
    mbl:"8878071281", 
    jd:"Data Scientist", 
    isMarried:false, 
    displayName:function(){
        console.log("suyash kumar")
    }
}


person.displayName()